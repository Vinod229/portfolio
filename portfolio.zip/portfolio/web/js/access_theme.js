$(document).ready(function(){
    // alert('test');
    $('#search_services').select2({
        placeholder: 'Search for service providers ...',
        dataType: 'json',
        minimumInputLength: 3,
        maximumSelectionLength: 2,
        multiple: true,
        ajax: {
            url: '/index.php/service/getall',
            processResults: function (data) {
                console.log(data);
                return {
                    results: JSON.parse(data)
                };
            }
        }
    });
});
