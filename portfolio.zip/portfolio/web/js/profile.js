$(document).ready(function(){


    /**
     * Add Service
     */
    $('.addServiceBtn').on('click', function(){
        $('.addService').click();
    });
    $('#addServiceBtn').on('click', function(){
        var serviceName = $('#serviceNameField').val();
        var serviceHTML = '';
        if(serviceName != '' & serviceName != 'undefined'){
            $.ajax({
                url: '/index.php/service/addservice',
                data: { 
                    service_name: serviceName
                },
                success: function(result){
                    var parsedResult = JSON.parse(result);
                    serviceHTML += '<li><span class="li_text">'+ parsedResult.sname +'</span><span class="li_options"><i class="fa fa-edit" data-sid="'+ parsedResult.sid +'" data-toggle="modal" data-target="#updateServicePopup"></i><i class="fa fa-trash" data-sid="'+ parsedResult.sid +'" data-toggle="modal" data-target="#deleteServicePopup"></i></span></li>';
                    $('#serviceNameField').val('');
                    $('.addService').click();
                    $('.services_wrapper ul').append(serviceHTML);
                }
            }); 
        } else {
            $('#serviceNameField').addClass('validationError');
        }
    });

    
    /**
     * Edit Service
     */
    $('.editServiceBtn').on('click', function(){
        var sid = $(this).data('sid');
        var currentName = $(this).parentsUntil('.service_'+sid).parent().find('.li_text').text();
        $('.update_service_id').val(sid);
        $('.old_service_name').val(currentName);
        $('.update_service_field').val(currentName);
        $('.editService').click();
    });
    $('#updateServiceBtn').on('click', function(){
        var newServiceName = $('.update_service_field').val();
        var oldServiceName = $('.old_service_name').val();
        var serviceId = $('.update_service_id').val();
        var serviceHTML = '';
        if(newServiceName != '' & newServiceName != 'undefined' & newServiceName != oldServiceName){
            $.ajax({
                url: '/index.php/service/updateservice',
                data: { 
                    service_id: serviceId,
                    new_service_name: newServiceName
                },
                success: function(result){
                    var parsedResult = JSON.parse(result);
                    if(parsedResult.status){
                        $('.service_'+parsedResult.sid).find('.li_text').text(parsedResult.sname);
                        $('.editService').click();
                    }
                }
            }); 
        } else {
            $('#serviceNameField').addClass('validationError');
        }
    });


    /**
     * Delete Service
     */
    $('.deleteServiceBtn').on('click', function(){
        var sid = $(this).data('sid');
        $('.confirmDeleteService').val(sid);
        $('.deleteService').click();
    });
    $('.confirmDeleteService').on('click', function(){
        var sid = $(this).val();
        $.ajax({
            url: '/index.php/service/deleteservice',
            data: { 
                s_id: sid
            },
            success: function(status){
                if(status){
                    $('.service_'+sid).hide();
                    $('.deleteService').click();
                }
            }
        }); 
    });
});