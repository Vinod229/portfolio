<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

    /* @var $this yii\web\View */

    $this->title = 'Reset Password';
?>


        <div class="col-xs-7 accessPageRight">
            <div class="boqForm">
                <div class="heading">
                    <h1>Bill of Quantity</h1>
                    <h5>Customization Application</h5>
                </div>
                
                <div class="resetpwdForm">
                    <?php 
                        $form = ActiveForm::begin(['id' => 'resetpwd-form']);
                        /*
                        ([
                            'id' => 'resetpwd-form',
                            'fieldConfig' => [
                                'options' => [
                                    'tag' => false,
                                ],
                                'template' => "{input}{error}",
                            ],
                        ]); 
                        */
                    ?>
                    <?= $form->field($model, 'authKey')->hiddenInput(['placeholder' => 'Password', 'value' => $_GET['authKey'], 'class' => 'formField resetFormField'])->label(false); ?>
                    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Password', 'class' => 'formField resetFormField'])->label(false); ?>
                    <?= $form->field($model, 'repeat_password')->passwordInput(['placeholder' => 'Confirm Password', 'class' => 'formField resetFormField'])->label(false); ?>
                    <div class="formActions">
                        <?= Html::submitButton('SUBMIT', ['class' => 'formBtn activeBtn resetpwdSubmitBtn', 'name' => 'resetpwd-button']) ?>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>
