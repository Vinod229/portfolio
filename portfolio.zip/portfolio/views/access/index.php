<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;

$this->title = 'Search';
?>

<div id="main_wrapper" class="d-flex justify-content-center align-items-center">
<div class="home_wrapper">
    
    <div class="welcome_wrapper">
        <h1>WELCOME</h1>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry <a href="#">JOIN US HERE</a>. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        <?php $form = ActiveForm::begin(['id' => 'search-form']); ?>
        <div class="search_wrapper">
            <select name="search_key[]" id="search_services" placeholder="Search here..."></select>
            <button class="home_search_btn">SEARCH</button>
        </div>
        <?php ActiveForm::end(); ?>
        <div class="access_options">
            <a href="<?= Url::to(['/access/register/'])?>" class="btn btn-default">JOIN US NOW</a>
            <a href="<?= Url::to(['/access/login/'])?>" class="btn btn-primary">LOGIN HERE</a>
        </div>
    </div>

</div>
</div>