<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;
use yii\helpers\Url;

    /* @var $this yii\web\View */

    $this->title = 'Register';
?>

<div id="main_wrapper" class="d-flex justify-content-center align-items-center">
    <div class="access_wrapper">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-sm-12 col-md-6 col-lg-8 d-none d-md-block">
                    <div class="welcome_wrapper">
                        <h1>WELCOME</h1>
                        <p>PORTFOLIO is a power full tool which helps people to showcase their work, and maintain a good relationship with clients and customers. Please ignore if you aready having an account. Please <a href="#">LOGIN HERE</a> to access your account.</p>
                        <a href="<?= Url::to(['/'])?>" class="btn btn-primary">SEARCH HERE</a>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="access_form register_form">
                        <h3>JOIN US</h3>
                        <?php $form = ActiveForm::begin(['id' => 'register-form']); ?>
                            
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'name')->textInput(['placeholder' => '* FULL NAME', 'class' => 'formField registerFormField'])->label(false); ?>
                        </div>
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'phone')->textInput(['placeholder' => '* PHONE', 'class' => 'formField registerFormField','pattern' => '[0-9]{10}', 'title' => 'You can enter only 10 digits...'])->label(false); ?>
                        </div> 
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'email_id')->textInput(['placeholder' => '* Email ID', 'class' => 'formField registerFormField'])->label(false); ?>
                        </div>
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'city')->textInput(['placeholder' => '* CITY', 'class' => 'formField registerFormField'])->label(false); ?>
                        </div> 
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'profession')->textInput(['placeholder' => '* PROFESSION', 'class' => 'formField registerFormField'])->label(false); ?>
                        </div> 
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'password')->passwordInput(['placeholder' => '* PASSWORD', 'class' => 'formField registerFormField'])->label(false); ?>
                        </div> 
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'repeat_password')->passwordInput(['placeholder' => '* CONFIRM PASSWORD', 'class' => 'formField registerFormField'])->label(false); ?>
                        </div>
                        <div class="form_actions_wrapper">
                            <a href="<?= Url::to(['/access/login/'])?>" class="btn btn-default fbtn">LOGIN NOW</a>
                            <?= Html::submitButton('JOIN', ['class' => 'btn btn-primary tbtn', 'name' => 'register-button']) ?>
                        </div>
                        <?php ActiveForm::end(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>