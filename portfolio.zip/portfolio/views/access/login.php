<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model app\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;

$this->title = 'Login';
$this->params['breadcrumbs'][] = $this->title;
?>

<div id="main_wrapper" class="d-flex justify-content-center align-items-center">
    <div class="access_wrapper">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-sm-12 col-md-6 col-lg-8 d-none d-md-block">
                    <div class="welcome_wrapper">
                        <h1>WELCOME</h1>
                        <p>PORTFOLIO is a power full tool which helps people to showcase their work, and maintain a good relationship with clients and customers. Please ignore if you aready having an account. Please <a href="#">LOGIN HERE</a> to access your account.</p>
                        <a href="<?= Url::to(['/'])?>" class="btn btn-primary">SEARCH HERE</a>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="access_form login_form">
                        <h3>LOGIN</h3>
                        <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'email_id')->textInput(['placeholder' => '* Email ID', 'class' => 'form_field'])->label(false); ?>
                        </div>
                        <div class="form_field_wrapper">
                            <?= $form->field($model, 'password')->passwordInput(['placeholder' => '* PASSWORD', 'class' => 'form_field'])->label(false); ?>
                        </div> 
                        <div class="form_actions_wrapper">
                            <a href="<?= Url::to(['/access/register/'])?>" class="btn btn-default fbtn">JOIN NOW</a>
                            <?= Html::submitButton('LOGIN', ['class' => 'btn btn-primary tbtn', 'name' => 'login-button']) ?>
                        </div>
                        <a href="<?= Url::to(['/access/forgotpassword/'])?>" class="fl">Forgot Password?</a>
                        <?php ActiveForm::end(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>