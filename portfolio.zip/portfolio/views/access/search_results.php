<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;

$this->title = 'Search Results';
?>
<div id="main_wrapper">
<div class="home_wrapper">
    <div class="welcome_wrapper">
        <h1>WELCOME</h1>
        <?php $form = ActiveForm::begin(['id' => 'search-form']); ?>
        <div class="search_wrapper">
            <select name="search_key[]" id="search_services" placeholder="Search here..."></select>
            <button class="home_search_btn">SEARCH</button>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
    <div class="container">
        <div class="results_wrapper">
            <h4>Search Results for: <span><?= $searchKey; ?></span></h4>
            <p><?= count($users); ?> results found.</p>
            <ul class="search_results">
                <?php foreach($users as $user) { ?>
                <li class="verified">
                <a href="<?= Url::to(['/profile/view/'.$user['u_code']]); ?>"><?= $user['name']; ?> <i class="fa fa-check-circle" aria-hidden="true"></i></a>
                </li>
                <?php } ?>
            </ul>
        </div>
        <div class="access_options">
            <a href="<?= Url::to(['/access/register/'])?>" class="btn btn-default">JOIN US NOW</a>
            <a href="<?= Url::to(['/access/login/'])?>" class="btn btn-primary">LOGIN HERE</a>
        </div>
    </div>
</div>
</div>