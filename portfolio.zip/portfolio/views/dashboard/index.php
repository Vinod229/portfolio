<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
use yii\grid\GridView;

$this->title = 'Dashboard';
$this->params['breadcrumbs'][] = '';
?>

<div id="dashboardSection">
    <div class="row">
        <div class="col-sm-8">
            <div class="col-sm-12">
                <div id="sireport" style="height: 370px; border:1px solid gray;">
                    <div id="chartContainer2" style="height: 100%; width: 100%;"></div>
                </div>
                <a href="<?php echo Yii::getAlias('@web').'sis.xlsx'; ?>"  class="btn btn-boq sis-6months-report">Download SI's Report</a>
                <br /><br />
            </div>
            <div class="col-sm-12">
                <div id="boqreport" style="height: 370px; border:1px solid gray;">
                    <div id="chartContainer1" style="height: 100%; width: 100%;"></div>
                </div>
                <a href="<?php echo Yii::getAlias('@web').'boqs.xlsx'; ?>" class="btn btn-boq boq-6months-report">Download BOQ's Report</a>
            </div>
        </div>
        
        <div class="col-sm-4">
           <div class="well well-lg" style="border-radius: 0px;">
            <form class="filter-form form-horizontal">
                <div class="form-group">
                    <label class="control-label col-sm-4">Select Report : </label>
                    <div class="col-sm-8">
                        <select class="form-control" id="select-filters" name="select-filters">
                            <option value="select">Select</option>
                            <option value="BOQ">BOQ</option>
                            <option value="SI">SI</option>
                        </select>
                    </div>
                </div>
                    
                <div class="form-group">
                 <label class="control-label col-sm-4">From:</label>
                    <div class="col-sm-8">
                        <div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
                            <input class="form-control" type="text" name="from" class="fromdate" readonly placeholder="dd-mm-yyyy"/>
                            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-4">To:</label>
                    <div class="col-sm-8">
                        <div id="datepicker1" class="input-group date" data-date-format="mm-dd-yyyy">
                            <input class="form-control" type="text" name="todate" class="todate" readonly placeholder="dd-mm-yyyy"/>
                            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                        </div>
                    </div>
                </div>

                 <div class="form-group">
                    <label class="control-label col-sm-4"></label>
                    <div class="col-sm-8">
                    <input type="button" class="form-control report-submit btn-boq" value="Submit"/>
                    <a href="<?php echo Yii::getAlias('@web').'reports.xlsx'; ?>" class="all-reports"></a>
                    </div>
                </div>
                
            </form>
            </div>
        </div>
    </div>
</div>