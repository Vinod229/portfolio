<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\ProfileAsset;
use yii\helpers\Url;

ProfileAsset::register($this);

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?> | PORTFOLIO</title>
        <link rel="shortcut icon" href="/images/favicon.png">
        <?php $this->head() ?>
    </head>
    <body>
    <?php $this->beginBody() ?>

        <!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->
        <div id="main_wrapper" class="">
            <div class="header d-flex align-items-center" id="navbar">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6"></div>
                        <div class="col-lg-6">
                        <?php if(!Yii::$app->user->isGuest){ ?>
                            <ul class="primary-nav">
                                <li><?= Html::a('<i class="fa fa-home" aria-hidden="true"></i> Home', Url::to(['/'])); ?></li>
                                <li><?= Html::a('<i class="fa fa-cog" aria-hidden="true"></i> Settings', Url::to(['/profile/changepassword'])); ?></li>
                                <li><?= Html::a('<i class="fa fa-sign-out" aria-hidden="true"></i> Logout', Url::to(['/access/logout'])); ?></li>
                            </ul>
                        <?php } else { ?>
                            <ul class="primary-nav">
                                <li><?= Html::a('<i class="fa fa-home" aria-hidden="true"></i> Home', Url::to(['/'])); ?></li>
                                <li><?= Html::a('<i class="fa fa-user-plus" aria-hidden="true"></i> Join Us', Url::to(['/access/register'])); ?></li>
                                <li><?= Html::a('<i class="fa fa-lock" aria-hidden="true"></i> Login', Url::to(['/access/login'])); ?></li>
                            </ul>
                        <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <?= $content ?>
        </div>


        
            
        
    <?php $this->endBody() ?>
    </body>

    
    <!-- Add Project Modal -->
    <div class="modal fade" id="addProjectPopup">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
      
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Project Title *</label>
                        <input type="text" class="add_project_field" name="title" placeholder="ENTER SERVICE NAME">
                    </div>
                    <div class="form-group">
                        <label for="excerpt">Short Description</label>
                        <textarea class="add_project_field" name="excerpt" rows="4" placeholder="Enter Short Description"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="content">Description</label>
                        <textarea class="add_project_field content" name="content"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="fimg">Featured Image *</label>
                        <div class="upload_file_container">  
                            <input class="input_file" id="my-file" type="file">
                            <label tabindex="0" for="my-file" class="input_file_trigger">Select an Image</label>
                        </div>
                        <p class="file-return"></p>
                    </div>
                    <div class="form-group">
                        <label for="fvideo">Upload Video</label>
                        <div class="upload_file_container">  
                            <input class="input_file" id="my-file" type="file">
                            <label tabindex="0" for="my-file" class="input_file_trigger">Select a Video</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="fvideo">Gallery</label>
                        <div class="upload_file_container">  
                            <input class="input_file" id="my-file" type="file">
                            <label tabindex="0" for="my-file" class="input_file_trigger">Select Gallery Images</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12  col-lg-6"></div>
                        <div class="col-sm-12 col-lg-6">
                            <div class="form_actions_wrapper">
                                <button class="btn btn-default fbtn" data-dismiss="modal">CANCEL</button>
                                <button class="btn btn-primary tbtn">ADD PROJECT</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Delete Project Modal -->
    <div class="modal fade" id="deleteProjectPopup">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
      
                <!-- Modal body -->
                <div class="modal-body">
                <p>Are you sure you want to delete this Project?</p>
                </div>
        
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="form_actions_wrapper">
                        <button class="btn btn-default fbtn" data-dismiss="modal">NO</button>
                        <button class="btn btn-primary tbtn">YES</button>
                    </div>
                </div>
      
            </div>
        </div>
    </div>

    <!-- Add Service Modal -->
    <div class="modal fade" id="addServicePopup">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
      
                <!-- Modal body -->
                <div class="modal-body">
                    <input type="text" class="add_service_field model_field" id="serviceNameField" placeholder="Enter Service Name">
                </div>
        
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="form_actions_wrapper">
                        <button class="btn btn-default fbtn" data-dismiss="modal">CANCEL</button>
                        <button class="btn btn-primary tbtn" id="addServiceBtn">ADD SERVICE</button>
                    </div>
                </div>
      
            </div>
        </div>
    </div>

    <!-- Update Service Modal -->
    <div class="modal fade" id="updateServicePopup">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
      
                <!-- Modal body -->
                <div class="modal-body">
                    <input type="text" class="update_service_field model_field">
                    <input type="hidden" class="old_service_name">
                    <input type="hidden" class="update_service_id">
                </div>
        
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="form_actions_wrapper">
                        <button class="btn btn-default fbtn" data-dismiss="modal">CANCEL</button>
                        <button class="btn btn-primary tbtn" id="updateServiceBtn">UPDATE SERVICE</button>
                    </div>
                </div>
      
            </div>
        </div>
    </div>

    <!-- Delete Service Modal -->
    <div class="modal fade" id="deleteServicePopup">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
      
                <!-- Modal body -->
                <div class="modal-body">
                <p>Are you sure you want to delete this Service?</p>
                </div>
        
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="form_actions_wrapper">
                        <button class="btn btn-default fbtn" data-dismiss="modal">NO</button>
                        <button class="btn btn-primary tbtn confirmDeleteService">YES</button>
                    </div>
                </div>
      
            </div>
        </div>
    </div>


    
    
</html>
<?php $this->endPage() ?>

