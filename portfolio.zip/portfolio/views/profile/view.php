<?php
 use yii\helpers\Html;
 use yii\helpers\Url;
 use yii\bootstrap\ActiveForm;

 $this->title = 'View Profile';
?>

<div class="profile_section">
    <div class="container">
        <div class="row">
                
            <div class="col-lg-4">
                <div class="profile_card">
                    <div class="pc_ppic"></div>
                    <div class="pc_pinfo d-flex flex-wrap justify-content-center">
                        <div class="pc_pinfo_pic" style="background-size: cover; background-position: center; background-image: url('/uploads/profile_pictures/<?= $user->u_picture; ?>');"></div>
                        <h4><?= $user->name; ?></h4>
                        <p><?= $user->email_id; ?></p>
                        <h5><?= $user->conumber; ?> <i class="fa fa-check-circle" aria-hidden="true"></i></h5>
                        <div class="score_wrapper"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="section_wrapper profile_details_wrapper">

                    <div class="row">
                        <div class="col-sm-12">
                            <p><strong>CO Number: </strong> <?= $user->conumber; ?></p>
                        </div>
                        <div class="col-sm-12">
                            <p><strong>Phone Number: </strong> <?= $user->phone; ?></p>
                        </div>
                        <div class="col-sm-12">
                            <p><strong>Experience: </strong> <?= $user->experience; ?></p>
                        </div>
                        <div class="col-sm-12">
                            <p><strong>City: </strong> <?= $user->city; ?></p>
                        </div>
                        <div class="col-sm-12">
                            <p><strong>Profession: </strong> <?= $user->profession; ?></p>
                        </div>
                        <div class="col-sm-12">
                            <p><strong>Education: </strong> <?= $user->education; ?></p>
                        </div>
                        <div class="col-sm-12">
                            <p><strong>Profile Summary </strong> 
                            <br>
                            <?= $user->summary; ?></p>
                        </div>
                    </div>
                </div>
            </div>
                
        </div>
    </div>
</div>

<div class="services_section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-4"></div>
            <div class="col-sm-12 col-lg-8">
                <div class="row sec_title">
                    <div class="col-6"><h4>SERVICES</h4></div>
                    <div class="col-6"></div>
                </div>
                <div class="section_wrapper services_wrapper">
                    <ul>
                        <?php foreach($services as $service){ ?>
                        <li class="service_<?= $service['s_id']; ?>">
                            <span class="li_text"><?= $service['s_name']; ?></span>
                            <span class="li_options">
                                
                            </span>
                        </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>