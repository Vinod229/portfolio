<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
 
$this->title = 'Change Password';
$this->params['breadcrumbs'][] = ['label' => 'Profile', 'url' => ['/profile/']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="profile_section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12"><?= Yii::$app->session->getFlash('changePwdSuccess'); ?> </div>

            <div class="col-lg-4">
                <div class="profile_card">
                    <div class="pc_ppic"></div>
                    <div class="pc_pinfo d-flex flex-wrap justify-content-center">
                        <div class="pc_pinfo_pic" style="background-size: cover; background-position: center; background-image: url('/uploads/profile_pictures/<?= $user->u_picture; ?>');"></div>
                        <h4><?= $user->name; ?></h4>
                        <p><?= $user->email_id; ?></p>
                        <h5><?= $user->conumber; ?> <i class="fa fa-check-circle" aria-hidden="true"></i></h5>
                        <div class="score_wrapper"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="section_wrapper profile_details_wrapper">
                    <?php $form = ActiveForm::begin(['id' => 'change-password-form']); ?>
                    <?= $form->field($pModel, 'old_password', ['template' => '<label for="email" class="control-label">{label} * :</label>{input}{error}'])
                                ->passwordInput(['placeholder' => 'Old Password', 'class' => 'form-control']); ?>

                    <?= $form->field($pModel, 'password', ['template' => '<label for="email" class="control-label">{label} * :</label>{input}{error}'])
                            ->passwordInput(['placeholder' => 'New Password', 'class' => 'form-control']); ?>

                    <?= $form->field($pModel, 'repeat_password', ['template' => '<label for="email" class="control-label">{label} * :</label>{input}{error}'])
                            ->passwordInput(['placeholder' => 'Confirm Password', 'class' => 'form-control']); ?>
                    
                    <div class="form-group formActions">
                        <?= Html::submitButton('Change Password', ['class' => 'btn btn-primary', 'name' => 'changePwd-button']); ?>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>
            </div>

        </div>
    </div>
</div>