<?php
 use yii\helpers\Html;
 use yii\helpers\Url;
 use yii\bootstrap\ActiveForm;
 
 $this->title = 'Update Profile';
 $this->params['breadcrumbs'][] = ['label' => 'Profile', 'url' => ['/profile/']];
 $this->params['breadcrumbs'][] = $this->title;
?>

        <div class="profile_section">
            <div class="container">
                <div class="row">
                
                    <div class="col-lg-4">
                        <?php $form = ActiveForm::begin(['id' => 'profile-form', 'class' => 'form-horizontal']); ?>
                        <div class="profile_card">
                            <div class="pc_ppic"></div>
                            <div class="pc_pinfo d-flex flex-wrap justify-content-center">
                                <div class="pc_pinfo_pic" style="background-size: cover; background-position: center; background-image: url('/uploads/profile_pictures/<?= Yii::$app->user->identity->u_picture; ?>');">
                                    <div class="picoverlay d-flex align-items-center justify-content-center">
                                        <?= $form->field($pModel, 'u_picture', ['template' => '{input}{error}'])->fileInput()->label(false); ?>
                                        <i class="fa fa-upload"></i>
                                    </div>
                                </div>
                                <h4><?= $user->name; ?></h4>
                                <p><?= $user->email_id; ?></p>
                                <h5><?= $user->conumber; ?> <i class="fa fa-check-circle" aria-hidden="true"></i></h5>
                                <div class="score_wrapper"></div>
                            </div>
                        </div>
                        <div class="storage_wrapper">
                            <p>Storage (25%)</p>
                            <div class="storage_bar">
                                <div class="storate_progress"></div>
                            </div>
                            <span class="storage_msg">128.00 MB used out of 5GB.</span>
                        </div>
                    </div>
                    
                    <div class="col-lg-8">
                        <div class="section_wrapper profile_details_wrapper">
                            <div class="row">
                                <div class="col-sm-12 col-lg-6">
                                    <?= $form->field($pModel, 'name', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'Full Name', 'value' => $user->name, 'class' => 'form-control']); ?>
                                </div>
                                <div class="col-sm-12 col-lg-6">
                                    <?= $form->field($pModel, 'conumber', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'CO Number', 'value' => $user->conumber, 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-lg-6">
                                    <?= $form->field($pModel, 'phone', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'Phone Number', 'value' => $user->phone, 'class' => 'form-control']); ?>
                                </div>
                                <div class="col-sm-12 col-lg-6">
                                    <?= $form->field($pModel, 'experience', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'Years of Experience', 'value' => $user->experience, 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-lg-6">
                                    <?= $form->field($pModel, 'city', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'CITY', 'value' => $user->city, 'class' => 'form-control']); ?>
                                </div>
                                <div class="col-sm-12 col-lg-6">
                                    <?= $form->field($pModel, 'profession', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'Profession', 'value' => $user->profession, 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-lg-12">
                                    <?= $form->field($pModel, 'education', ['template' => '<label for="name">{label} * :</label>{input}{error}'])
                        ->textInput(['placeholder' => 'Education', 'value' => $user->education, 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <?= $form->field($pModel, 'summary', ['template' => '<label for="address">{label} *:</label>{input}{error}'])
                        ->textArea(['placeholder' => 'Profile Summary...', 'value' => $user->summary, 'rows' => 4, 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="row">   
                                <div class="col-sm-12 col-lg-6">
                                    <?php /* ?><a href="<?= Url::to(['/profile/changepassword']); ?>" class="btn btn-default fl">Change Password</a><?php */ ?>
                                </div>
                                <div class="col-sm-12 col-lg-6">
                                    <?= Html::submitButton('Update Profile', ['class' => 'btn btn-primary fr', 'name' => 'profile-submit']) ?>
                                </div>
                            </div>
                        </div>
                        <?php ActiveForm::end(); ?>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="services_section">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-lg-4"></div>
                    <div class="col-sm-12 col-lg-8">
                        <div class="row sec_title">
                            <div class="col-6"><h4>SERVICES</h4></div>
                            <div class="col-6">
                                <button class="btn btn-primary fr addServiceBtn">ADD SERVICE</button>
                                <input type="hidden" name="addService" class="addService" data-toggle="modal" data-target="#addServicePopup">
                            </div>
                        </div>
                        <div class="section_wrapper services_wrapper">
                            <ul>
                                <?php foreach($services as $service){ ?>
                                <li class="service_<?= $service['s_id']; ?>">
                                    <span class="li_text"><?= $service['s_name']; ?></span>
                                    <span class="li_options">
                                        <i class="fa fa-trash deleteServiceBtn" data-sid="<?= $service['s_id']; ?>"></i>
                                        <i class="fa fa-edit editServiceBtn" data-sid="<?= $service['s_id']; ?>"></i>
                                        
                                        <input type="hidden" name="editService" class="editService" data-toggle="modal" data-target="#updateServicePopup">
                                        <input type="hidden" name="deleteService" class="deleteService" data-toggle="modal" data-target="#deleteServicePopup">
                                    </span>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="projects_section">
            <div class="container">
                <div class="project_slider_section">
                    <div class="row sec_title">
                        <div class="col-6"><h4>PROJECTS</h4></div>
                        <div class="col-6"><a href="<?= Url::to(['/project/add']); ?>" class="btn btn-primary fr">ADD PROJECT</a></div>
                        <?php /* ?><div class="col-6"><button class="btn btn-primary fr" data-toggle="modal" data-target="#addProjectPopup">ADD PROJECT</button></div><?php */ ?>
                    </div>
                    
                    <div class="project_slider">
                        <?php foreach($projects as $project) { ?>
                            <div class="project_slide">
                            <div class="project_slide_img" style="background-size: cover; background-position: center; background-image: url('/uploads/project_pictures/<?= $project['p_picture']; ?>');">
                                <div class="project_slide_img_overlay">
                                    <a href="project.html"><i class="fa fa-edit"></i></a>
                                    <i class="fa fa-trash" data-toggle="modal" data-target="#deleteProjectPopup"></i>
                                </div>
                            </div>
                            <div class="project_slide_details">
                                <h5><a href="<?= Url::to(['/project/view/'.$project['p_id']]); ?>"><?= $project['p_title']; ?></a></h5>
                                <p><?=  $project['p_summary']; ?></p>
                                <div class="dropdown dropup rating_wrapper">
                                    <div class="" data-toggle="dropdown">
                                        <?php for($i = 0; $i < $project['p_rating']; $i++ ){ ?>
                                            <i class="fa fa-star star_active"></i>
                                        <?php } ?>
                                        <?php for($i = 0; $i < 5 - $project['p_rating']; $i++ ){ ?>
                                            <i class="fa fa-star star_inactive"></i>
                                        <?php } ?>
                                    </div>
                                    <div class="dropdown-menu">
                                        <h5><?=  $project['client_name']; ?></h5>
                                        <p><?=  $project['client_email']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer_section"></div>
  