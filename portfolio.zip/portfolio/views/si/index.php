<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
use yii\grid\GridView;

$this->title = 'System Integrators';
$this->params['breadcrumbs'][] = $this->title;
?>

<div id="siOuterWrapper">
<?php
    echo GridView::widget([
        'dataProvider' => $userDataProvider,
        'emptyText' => 'Oops, No System Integrators Found.',
        'summary' => '<div class="boqFilterWrapper">Showing {begin} - {end} of {totalCount} items </div>',
        'columns' => [
                        [
                            'class' => 'yii\grid\SerialColumn',
                            'headerOptions' => ['style' => 'width: 3%; text-align: center;'],
                            'contentOptions' => ['style' => 'width: 3%; text-align: center;'],
                        ],
                        [
                            'label' => 'Name',
                            'attribute' => 'name',
                            'headerOptions' => ['style' => 'width: 15%;'],
                            'value' => function($data){return $data['name'];}
                        ], 
                        [
                            'label' => 'Phone',
                            'attribute' => 'phone',
                            'headerOptions' => ['style' => 'width: 10%;'],
                            'value' => function($data){return $data['phone'];}
                        ], 
                        [
                            'label' => 'Email ID',
                            'attribute' => 'email_id',
                            'headerOptions' => ['style' => 'width: 15%;'],
                            'value' => function($data){return $data['email_id'];}
                        ],
                        [
                            'label' => 'Address',
                            'attribute' => 'address',
                            'headerOptions' => ['style' => 'width: 20%;'],
                            'value' => function($data){return $data['address'];}
                        ], 
                        [
                            'label' => 'Region',
                            'attribute' => 'region',
                            'headerOptions' => ['style' => 'width: 5%;'],
                            'visible' =>  Yii::$app->user->identity->role == 'admin' ? 1 : 0,
                            'value' => function($data){return $data['region'];}
                        ],  
                        [
                            'label' => 'Status',
                            'attribute' => 'active',
                            'headerOptions' => ['style' => 'width: 7%;'],
                            'value' => function($data){
                                if($data['active'] == 1){
                                    return 'Active';
                                } else {
                                    return 'In-Active';
                                }
                            }
                        ],
                        [
                            'label' => 'Actions',
                            'attribute' => 'active',
                            'format' => 'html',
                            'headerOptions' => ['style' => 'width: 5%;'],
                            'contentOptions' => function($model){
                                return ['data-emailid' => $model['email_id']];
                            },
                            'value' => function($data){
                                $actions = '';
                                if($data['active'] == 1){
                                    $actions .= Html::img('/images/cross.png', ['class' => 'actionBtn deactivateSI', 'alt' => 'De-Activate SI']);
                                } else {
                                    $actions .= Html::img('/images/tick.png', ['class' => 'actionBtn activateSI', 'alt' => 'Activate SI']);
                                }
                                //$actions .= Html::img('/images/delete.png', ['class' => 'actionBtn', 'alt' => 'Delete User']);
                                return $actions;
                            }
                        ]  
                    ],
                ]);
?>
</div>