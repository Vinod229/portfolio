<?php
 use yii\helpers\Html;
 use yii\helpers\Url;
 use yii\bootstrap\ActiveForm;
 use yii\grid\GridView;
 $this->title = $project['p_title'];
?>
<div class="profile_section">
    <div class="container">
            
        <div class="row">
            <div class="col-sm-4">
                <div class="profile_card">
                    <div class="pc_ppic"></div>
                    <div class="pc_pinfo d-flex flex-wrap justify-content-center">
                        <div class="pc_pinfo_pic" style="background-size: cover; background-position: center; background-image: url('/uploads/profile_pictures/<?= $user->u_picture; ?>');"></div>
                        <h4><?= $user->name; ?></h4>
                        <p><?= $user->email_id; ?></p>
                        <h5><?= $user->conumber; ?> <i class="fa fa-check-circle" aria-hidden="true"></i></h5>
                        <div class="score_wrapper"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="section_wrapper project_details_wrapper">
                    <h1><?= $project->p_title; ?></h1>
                    <h6><strong>Created On: </strong><?= $project->created_on; ?></h6>
                    <img src="/uploads/project_pictures/<?= $project->p_picture; ?>" alt="" class="img-fluid">
                    <div class="pro_content">
                    <?= $project->p_description; ?>
                    </div>
                </div>


                <div class="row">
                    <div class="col-sm-12 col-lg-6"><p></p></div>
                        <div class="col-sm-12 col-lg-6">
                            <a href="<?= Url::to(['/project/edit/'.$project->p_id]); ?>" class="btn btn-primary fr">EDIT PROJECT</a>
                        </div>
                    </div>
                </div> 

            </div>

        </div>
        
    </div>
</div>            