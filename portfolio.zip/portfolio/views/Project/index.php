<?php
 use yii\helpers\Html;
 use yii\helpers\Url;
 use yii\bootstrap\ActiveForm;
 use yii\grid\GridView;
 
 $this->title = 'Hogar Products';
 $this->params['breadcrumbs'][] = $this->title;
 $currencyType = Yii::$app->params['currencyType'];
?>

<input type="hidden" value="Open" class="btn btn-info confirmDelPro" data-toggle="modal" data-target="#delProConfirm">

<div id="productsOuterWrapper">
<div class="row">
<div class="col-sm-12"><?= Yii::$app->session->getFlash('updateProduct'); ?> </div>
    <?php /* ?>
    <div class="col-xs-4">
        <div class="taxonomySection">
            <ul>
            <?php foreach($productCategoryList as $category) { 
                ?>
                <li><?= $category['p_category']; ?></li>
            <?php } ?>
            </ul>
        </div>
    </div>
    <?php */ ?>
    <div class="col-xs-4">
        <div class="leftMenuOptions">
            <ul>
                <li class="activeOption">Hogar Products</li>
                <a href="<?= Url::to(['/product/nonhogar']); ?>"><li>Non-Hogar Products</li></a>
            </ul>
        </div>
    </div>
    <div class="col-xs-8">
        <div class="productFormSection">
            
                <?= GridView::widget([
                        'layout' => '<div class="productListWrapper">{summary}{items}{pager}</div>',
                        'dataProvider' => $dataHogarProvider,
                        'emptyText' => 'Oops, No Products Found.',
                        'pager' => [
                            'firstPageLabel'=>'First',
                            'lastPageLabel'=>'Last',
                            //'hideOnSinglePage' => true,
                            'maxButtonCount'=>5 // defalut 10   
                        ],
                        'summary' => '<div class="boqFilterWrapper">Showing Hogar product {begin} - {end} of {totalCount} items </div>',
                        'columns' => [
                            [
                                'class' => 'yii\grid\SerialColumn',
                                'headerOptions' => ['style' => 'width: 5%; text-align: center;'],
                                'contentOptions' => ['style' => 'width: 5%; text-align: center;'],
                            ],
                            [
                                'label' => 'Name',
                                'attribute' => 'p_name',
                                'headerOptions' => ['style' => 'width: 30%;'],
                                'value' => function($data){return $data['p_name'];}
                            ],
                            [
                                'label' => 'Code',
                                'attribute' => 'p_code',
                                'headerOptions' => ['style' => 'width: 20%;'],
                                'value' => function($data){return $data['p_code'];}
                            ],
                            [
                                'label' => 'Price',
                                'attribute' => 'p_price',
                                'contentOptions' => ['style' => 'text-align: right;'],
                                'headerOptions' => ['style' => 'width: 15%; text-align: right;'],
                                'value' => function($data) use ($currencyType){
                                    return Yii::$app->globalfunctions->currency($data['p_price'], $currencyType);
                                }
                            ],
                            [
                                'label' => 'Actions',
                                'format' => 'html',
                                'headerOptions' => ['style' => 'width: 15%;'],
                                'contentOptions' => function($model){
                                    return ['data-proid' => $model['p_id']];
                                },
                                'value' => function($data){
                                    $actions = '';
                                    $actions .= Html::a(Html::img('/images/edit.png', ['class' => 'actionBtn editProduct editProduct_'.$data['p_id'], 'alt' => 'Edit Product']), Url::to(['/product/edit/', 'id' => $data['p_id']]));
                                    $actions .= Html::img('/images/delete.png', ['class' => 'actionBtn deleteProduct deleteProduct_'.$data['p_id'], 'alt' => 'Delete Product']);
                                    return $actions;
                                }
                            ]
                        ],
                    ]);
                ?>
            </div>
            
        </div>
    
    </div>

</div>
