<?php
 use yii\helpers\Html;
 use yii\helpers\Url;
 use yii\bootstrap\ActiveForm;
 use yii\grid\GridView;
 
 $this->title = $project->p_title;
?>

<div class="profile_section">
    <div class="container">
            
        <div class="row">
            <div class="col-sm-4">
                <div class="profile_card">
                    <div class="pc_ppic"></div>
                    <div class="pc_pinfo d-flex flex-wrap justify-content-center">
                        <div class="pc_pinfo_pic" style="background-size: cover; background-position: center; background-image: url('/uploads/profile_pictures/<?= $user->u_picture; ?>');"></div>
                        <h4><?= $user->name; ?></h4>
                        <p><?= $user->email_id; ?></p>
                        <h5><?= $user->conumber; ?> <i class="fa fa-check-circle" aria-hidden="true"></i></h5>
                        <div class="score_wrapper"></div>
                    </div>
                </div>
            </div>

            <div class="col-sm-8">
                <?php $form = ActiveForm::begin(['id' => 'add-product-form']); ?>
                <div class="form-horizontal">

                    <?= $form->field($projectModel, 'p_id')->hiddenInput(['value' => $project->p_id])->label(false); ?>

                    <?= $form->field($projectModel, 'p_title', ['template' => '<div class="form-group"><label class="control-label">{label} * :</label>{input}{error}</div>'])
                        ->textInput(['placeholder' => 'ENTER PROJECT TITLE', 'value' =>  $project->p_title, 'class' => 'form-control add_project_field']); ?>
                    
                    <?= $form->field($projectModel, 'is_public', ['template' => '<div class="form-group"><label class="control-label">{label} :</label>{input}{error}</div>'])
                        ->checkBox(['class' => '']); ?>
                           
                    <?= $form->field($projectModel, 'p_summary', ['template' => '<div class="form-group"><label class="control-label">{label} * :</label>{input}{error}</div>'])
                        ->textArea(['placeholder' => 'Enter Short Description', 'value' =>  $project->p_summary, 'class' => 'form-control add_project_field']); ?>
                    
                    <?= $form->field($projectModel, 'p_description', ['template' => '<div class="form-group"><label class="control-label">{label} :</label>{input}{error}</div>'])
                        ->textArea(['placeholder' => 'Enter Short Description', 'value' =>  $project->p_description, 'class' => 'form-control add_project_field content']); ?>

                    <?= $form->field($projectModel, 'p_picture', ['template' => '<div class="form-group"><label class="control-label">{label} :</label><div class="upload_file_container">{input}<label tabindex="0" for="my-file" class="input_file_trigger">Select an Image</label>{error}</div><p class="file-return"></p></div>'])
                        ->fileInput(['placeholder' => 'Enter Short Description', 'class' => 'form-control add_project_field input_file']); ?>

                    <?= $form->field($projectModel, 'p_video', ['template' => '<div class="form-group"><label class="control-label">{label} :</label><div class="upload_file_container">{input}<label tabindex="0" for="my-file" class="input_file_trigger">Select a Video</label>{error}</div><p class="file-return"></p></div>'])
                        ->fileInput(['placeholder' => 'Enter Short Description', 'class' => 'form-control add_project_field input_file']); ?>

                </div>
                <div class="row">
                    <div class="col-sm-12 col-lg-6"><p>* Fields are required.</p></div>
                        <div class="col-sm-12 col-lg-6">
                            <?= Html::submitButton('Update Project', ['class' => 'btn btn-primary tbtn']) ?>
                        </div>
                    </div>
                </div> 
                <?php ActiveForm::end(); ?>
            </div>
        
        </div>
    </div>
</div>