<?php

return [
    'adminEmail' => 'admin@example.com',
    'currency' => '&#8377;',
    'currencyType' => 'INR',
    'amprating' => 5,
    'regions' => array(
        'north' => 'North',
        'west' => 'West',
        'east' => 'East',
        'south' => 'South',
        'south2' => 'South-2',
        'midsouth' => 'South-Mid'
    )
];

/* Usage
    <?= Yii::$app->params['amprating']; ?> 
*/