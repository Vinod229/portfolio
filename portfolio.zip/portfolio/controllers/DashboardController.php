<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\Customer;
use app\models\Product;
use app\models\BoqForm;
use app\models\Boq;
use app\models\Invoice;
use app\models\Floor;
use app\models\Room;
use yii\data\ArrayDataProvider;

class DashboardController extends Controller
{

    public $layout = 'boq';
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'index'],
                'rules' => [
                    [
                        'actions' => ['index'],
                        'allow' => true,
                        'matchCallback' => function ($rule, $action) {
                            return Yii::$app->user->identity->role == 'admin' ? true : false;
                        }
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }


    /**
     * Displays homepage.
     */
    public function actionIndex()
    {
        $boqModel = new BoqForm();
        $boqs = $boqModel->getBoqs();
        Yii::$app->runAction('reports/excel');
        Yii::$app->runAction('reports/sisexcel');
        return $this->render('index', ['boqs' => $boqs]);
    }



    
}
