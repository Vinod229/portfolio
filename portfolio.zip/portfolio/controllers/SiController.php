<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\AuthenticateForm;
use app\models\User;
use app\models\Notify;
use yii\data\ArrayDataProvider;

class SiController extends Controller
{

    public $layout = 'boq';
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'index'],
                'rules' => [
                    [
                        'actions' => ['index'],
                        'allow' => true,
                        'matchCallback' => function ($rule, $action) {
                            return (Yii::$app->user->identity->role == 'admin' || Yii::$app->user->identity->role == 'manager') ? true : false;
                        }
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        $u_model = new User();
        if (Yii::$app->user->identity->role == 'admin') {
            $users = $u_model->find()
                        ->where(['role' => 'si'])
                        ->asArray()
                        ->all();
        } else if(Yii::$app->user->identity->role == 'manager'){
            $users = $u_model->find()
                        ->where(['role' => 'si', 'region' => Yii::$app->user->identity->region])
                        ->asArray()
                        ->all();
        }
        
        
        $userDataProvider = new ArrayDataProvider([
            'allModels' => $users,
            'pagination' => [
                'pageSize' => 10,
            ],
            'sort' => [
                'attributes' => ['id', 'name'],
            ],
        ]);

        return $this->render('index', [
            'userDataProvider' => $userDataProvider,
        ]);
    }


    public function actionGetsis(){
        $u_model = new User();
        $users = $u_model->find()
                        ->select(['id' => 'user_id', 'text' => 'name'])
                        ->where(['role' => 'si'])
                        ->andWhere(['LIKE', 'name', $_GET['q']])
                        ->asArray()
                        ->all();
        return json_encode($users);
    }

}
