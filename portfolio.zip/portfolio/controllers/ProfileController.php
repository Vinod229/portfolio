<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\User;
use app\models\Service;
use app\models\ProjectForm;
use app\models\Project;
use app\models\AuthenticateForm;
use yii\web\UploadedFile;

class ProfileController extends Controller
{

    public $layout = 'profile';
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'index', 'changepassword'],
                'rules' => [
                    [
                        //'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }


    /**
     * Displays homepage.
     */
    public function actionIndex()
    {
        $userIdentity = Yii::$app->user->identity;

        $pModel = new AuthenticateForm();
        $serviceModel = new Service();
        $projectModel = new Project();
        
        $pModel->scenario = 'updateProfile';

        if ($pModel->load(Yii::$app->request->post())) {
            $pModel->u_picture = UploadedFile::getInstance($pModel, 'u_picture');
            
            if ($pModel->update()) {
                if($pModel->u_picture){
                    $pModel->u_picture->saveAs('uploads/profile_pictures/' . $pModel->u_picture->baseName . '_' . strtotime('now') . '.' . $pModel->u_picture->extension);
                }
                Yii::$app->session->setFlash('updateProfile', '<div class="alert alert-success tac fade in"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Your profile was updated successfully.</div>');
                return $this->redirect('/index.php/profile');
            }
            
        }

        $services = $serviceModel->getServices($userIdentity->user_id);
        $projects = $projectModel->getProjects($userIdentity->user_id);

        return $this->render('index', [
            'user' => $userIdentity,
            'pModel' => $pModel,
            'services' => $services,
            'projects' => $projects
        ]);
    }

    public function actionChangepassword()
    {
        $pModel = new AuthenticateForm();
        $pModel->scenario = 'changePassword';

        $loginIdentity = Yii::$app->user->identity;

        if ($pModel->load(Yii::$app->request->post())) {
            if ($pModel->changePwd()) {
                Yii::$app->session->setFlash('changePwdSuccess', '<div class="alert alert-success tac fade in"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Your passwrod is successfully changed. <br>Please login with the new credentials.</div>');
            }
        }

        return $this->render('changepassword', [
            'user' => $loginIdentity,
            'pModel' => $pModel
        ]);
    }

    public function actionView($u_code){
        
        $serviceModel = new Service();

        $userModel = User::findOne(['u_code'=> $u_code]);
        $services = $serviceModel->getServices($userModel->user_id);

        return $this->render('view', [
            'user' => $userModel,
            'services' => $services
        ]);
    }

    public function actionActivate()
    {
        $userModel = User::findOne(['email_id'=> $_REQUEST['email_id']]);  
        $userModel->active = 1;
        if ( $userModel->update() ) {

            // Account Activate Send Email
            $user = new User();
            $siemailid = $_REQUEST['email_id'];

           

            $regionalmanager = $user->find()
                                    ->select('email_id')
                                    ->where(['region' => $userModel->region])    
                                    ->andWhere(['role' => 'manager'])
                                    ->asArray()
                                    ->one();
            $regionalmanager = $regionalmanager['email_id'];

            Yii::$app->mailer->compose()
                ->setFrom('admin@hogarcontrols.com')
                ->setTo(['admin@hogarcontrols.com',$regionalmanager,$siemailid])
                ->setSubject('Account Activated')
                ->setHtmlBody($siemailid.' - account has been activated successfully')
                ->send();


            return true;
        } else {
            return false;
        }
    }
    public function actionDeactivate()
    {
        $userModel = User::findOne(['email_id'=> $_REQUEST['email_id']]);  
        $userModel->active = 0;
        if ( $userModel->update() ) {


             // Account Dectivate Send Email
             $user = new User();
             $siemailid = $_REQUEST['email_id'];
             $regionalmanager = $user->find()
                                     ->select('email_id')
                                     ->where(['region' => $userModel->region])    
                                     ->andWhere(['role' => 'manager'])
                                     ->asArray()
                                     ->one();
             $regionalmanager = $regionalmanager['email_id'];
 
             Yii::$app->mailer->compose()
                 ->setFrom('admin@hogarcontrols.com')
                 ->setTo(['admin@hogarcontrols.com',$regionalmanager,$siemailid])
                 ->setSubject('Account Deactivated')
                 ->setHtmlBody($siemailid.' - account has been deactivated')
                 ->send();
 


            return true;
        } else {
            return false;
        }
        
    }

    
}
