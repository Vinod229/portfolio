<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\Service;
use yii\data\ArrayDataProvider;

class ServiceController extends Controller
{

    public $layout = 'profile';
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Add Floor
     */
    public function actionAddservice()
    {
        $service = array();
        $serviceModel = new Service();
        $serviceModel->s_name = $_REQUEST['service_name'];
        $serviceModel->user_id = Yii::$app->user->identity->id;
        
        if($serviceModel->save()){
            $service['sid'] = $serviceModel->s_id;
            $service['sname'] = $serviceModel->s_name;
            return json_encode($service);
        }
    }

    /**
     * Update Floor
     */
    public function actionUpdateservice()
    {
        $serviceModel = Service::findOne(['s_id' => $_REQUEST['service_id']]); 
        $serviceModel->s_name = $_REQUEST['new_service_name'];
        
        if ( $serviceModel->update() ) {
            $result['status'] = true;
            $result['sid'] =  $_REQUEST['service_id'];
            $result['sname'] =  $_REQUEST['new_service_name'];
            return json_encode($result);
        } else {
            return false;
        }
    }

    /**
     * Delete Floor
     */
    public function actionDeleteservice()
    {
        $serviceModel = Service::findOne(['s_id' => $_REQUEST['s_id']]);  
        if($serviceModel->delete()){
            return true;
        } else {
            return false;
        }
    }


    public function actionGetall(){
        $services = Service::find()
                            ->select(['id' => 's_name', 'text' => 's_name'])
                            ->where(['LIKE', 's_name', $_GET['q']])
                            ->asArray()
                            ->all();
        
        return json_encode($services);
    }

    
}
