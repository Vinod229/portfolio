<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
//use yii\filters\VerbFilter;
use app\models\AuthenticateForm;
use app\models\Notify;
use app\models\Service;
use app\models\User;

class AccessController extends Controller
{

    public $layout = 'access';

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        
        return [
            /*
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['access/logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
            */
            
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'app\components\MathCaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 42 : null,
            ],
        ];
    }

    
    /**
     * Displays SearchPage.
     *
     * @return string
     */
    public function actionIndex()
    {
        $users = array();
        $searchKey = '';

        if (!Yii::$app->user->isGuest) {
            return $this->redirect(Yii::$app->urlManager->createUrl('/profile'));
        }

        if(Yii::$app->request->post()){
            $searchKeyArray = Yii::$app->request->post()['search_key'];
            $users = Service::find()
                        ->select('services.user_id, users.u_code, users.name')
                        ->leftJoin('users', 'users.user_id = services.user_id')
                        ->where(['IN', 's_name', $searchKeyArray])
                        ->asArray()
                        ->all();
            foreach($searchKeyArray as $key){
                $searchKey .= $key . ', ';
            }
            return $this->render('search_results', 
                    [
                        'users' => $users,
                        'searchKey' => $searchKey
                    ]);
        }
        
        return $this->render('index');
    }


    /**
     * Displays Login Page.
     *
     * @return string
     */
    public function actionLogin()
    {
        $l_model = new AuthenticateForm();
        $l_model->scenario = 'login';
        
        if ($l_model->load(Yii::$app->request->post()) && $l_model->login()) {
            return $this->redirect('/profile/index');
        }
        return $this->render('login', [
            'model' => $l_model,
        ]);
    }

    /**
     * Register action
     */
    public function actionRegister()
    {
        
        if (!Yii::$app->user->isGuest) {
            return $this->redirect('index.php/profile');
        }

        $r_model = new AuthenticateForm();
        $r_model->scenario = 'register';
        
        if ($r_model->load(Yii::$app->request->post()) && $r_model->register()) {
            
            /*send email 
            $verificationLink = 'http://boq.hogarcontrols.com/access/verifyemail?email='.$r_model->email_id;
            Yii::$app->mailer->compose()
                ->setFrom('admin@hogarcontrols.com')
                ->setTo($r_model->email_id)
                ->setSubject('Please Verify your Email Address')
                ->setHtmlBody('Click the below link to verify your email.<br><a href="' . $verificationLink . '">Verify</a>')
                ->send();
            Yii::$app->runAction('notify/addusernotify', ['email_id'=> $r_model->email_id, 'region'=>$r_model->region]);
            */
            return $this->redirect('/access/login');
        }
        return $this->render('register', [
            'model' => $r_model,
        ]);
    }

    // verification email
    public function actionVerifyemail($email)
    {
        
        $user = new User();
        $useridentity = $user->findOne(['email_id' => $email]);
        $useridentity->verification =  1;
        $useridentity->update() ? $useridentity->verification : false;
      

        $regionalmanagaer = $user->find()
                                ->select('email_id')
                                ->where(['region' => $useridentity->region])
                                ->andWhere(['role' => 'manager'])
                                ->asArray()
                                ->one();
        $regionalmanagaer = $regionalmanagaer['email_id'];
        // Account Activatiion Request

        Yii::$app->mailer->compose()
                ->setFrom('admin@hogarcontrols.com')
                ->setTo(['admin@hogarcontrols.com',$regionalmanagaer])
                ->setSubject('New User Created')
                ->setHtmlBody('Please Activate new user')
                ->send();



        return $this->redirect('/');

    }


    /**
     * Register action
     */
    public function actionForgotpassword()
    {
        $r_model = new AuthenticateForm();
        $r_model->scenario = 'forgetpwd';
        
        if ($r_model->load(Yii::$app->request->post()) && $r_model->validate())
        {
            $resetLink = 'http://boq.hogarcontrols.com/access/resetpassword?authKey='.$r_model->forgetpwd();
            Yii::$app->mailer->compose()
                ->setFrom('admin@hogarcontrols.com')
                ->setTo($r_model->email_id)
                ->setSubject('Reset Password')
                ->setHtmlBody('Click the below link to reset your password.<br><a href="' . $resetLink . '">Reset Password</a>')
                ->send();
            return $this->redirect('/');
        }
        return $this->render('forgetpwd', [
            'model' => $r_model,
        ]);
    }


    /**
     * Register action
     */
    public function actionResetpassword()
    {
        $r_model = new AuthenticateForm();
        $r_model->scenario = 'resetpwd';
        if ($r_model->load(Yii::$app->request->post()) && $r_model->resetpwd())
        {
            Yii::$app->session->setFlash('resetSuccess', '<div class="alert alert-success tac fade in"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Your passwrod is successfully changed. <br>Please login with the new credentials.</div>');
            return $this->redirect('/');
        }
        return $this->render('resetpwd', [
            'model' => $r_model,
        ]);
    }


    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();
        return $this->redirect('/');
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
}
