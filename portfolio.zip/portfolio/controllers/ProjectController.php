<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\ProjectForm;
use app\models\Project;
use yii\data\ArrayDataProvider;
use yii\web\UploadedFile;
use yii\data\Pagination;
use app\models\User;


use yii\helpers\Url;

class ProjectController extends Controller
{

    public $layout = 'profile';
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'hogar', 'nonhogar', 'add', 'edit'],
                'rules' => [
                    [
                        //'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                    /*
                    [
                        'actions' => ['hogar', 'nonhogar', 'add', 'edit'],
                        'allow' => true,
                        'matchCallback' => function ($rule, $action) {
                            return Yii::$app->user->identity->role == 'admin' ? true : false;
                        }
                    ],
                    */
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }


    /**
     * Add Project
     */
    public function actionAdd()
    {
        $userIdentity = Yii::$app->user->identity;

        $projectModel = new ProjectForm();
        
        $projectModel->scenario = 'addProject';

        if ($projectModel->load(Yii::$app->request->post())){
            $projectModel->p_picture = UploadedFile::getInstance($projectModel, 'p_picture');

            if ($projectModel->addProject()) {
                if($projectModel->p_picture){
                    $projectModel->p_picture->saveAs('uploads/project_pictures/' . $projectModel->p_picture->baseName . '_' . strtotime('now') . '.' . $projectModel->p_picture->extension);
                }
                // notification for adding the Project
                $projectid = Yii::$app->db->getLastInsertID();
                return $this->redirect(Url::to(['/project/view/'.$projectid]));
            }
            
        }
        return $this->render('add', [
            'projectModel' => $projectModel,
            'user' => $userIdentity
        ]);
    }


    /**
     * View Project
     */
    public function actionView($project_id)
    {
        $userIdentity = Yii::$app->user->identity;

        $projectModel = new ProjectForm();

        $project = Project::findOne(['p_id' => $project_id]);

        return $this->render('view', [
            'projectModel' => $projectModel,
            'user' => $userIdentity,
            'project' => $project
        ]);
    }


    /**
     * Edit Product
     */
    public function actionEdit($project_id)
    {
        
        $userIdentity = Yii::$app->user->identity;

        $projectModel = new ProjectForm();
        $projectModel->scenario = 'updateProject';
        $project = Project::findOne(['p_id' => $project_id]);
        
        if ($projectModel->load(Yii::$app->request->post())){
            $projectModel->p_picture = UploadedFile::getInstance($projectModel, 'p_picture');
            
            if ($projectModel->updateProject()) {
                if($projectModel->p_picture){
                    $projectModel->p_picture->saveAs('uploads/project_pictures/' . $projectModel->p_picture->baseName . '_' . strtotime('now') . '.' . $projectModel->p_picture->extension);
                }
                Yii::$app->session->setFlash('updateProject', '<div class="alert alert-success tac fade in"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Product was updated successfully.</div>');

                  // notification for editing the product
                $projectid = $project_id;
                return $this->redirect(Url::to(['/project/view/'.$projectid]));
            }
            
        }

        
        return $this->render('edit', [
            'projectModel' => $projectModel,
            'user' => $userIdentity,
            'project' => $project
        ]);
    }

    /**
     * Get Product Details
     */
    public function actionGet()
    {
        $product = Invoice::find()
                            ->select('*')
                            ->leftJoin('products', 'products.p_id = invoices.p_id')
                            ->where(['invoices.boq_id' => $_REQUEST['boq_id'], 'invoices.invoice_id' => $_REQUEST['ip_id']])
                            ->asArray()
                            ->one();
        
        return json_encode($product);
    }

    public function actionGetall(){
        $products = Product::find()
                            ->select(['id' => 'p_id', 'text' => 'p_name'])
                            ->where(['LIKE', 'p_name', $_GET['q']])
                            ->asArray()
                            ->all();
        
        return json_encode($products);
    }

    public function actionDeleteproduct()
    {
        $productModel = Product::findOne(['p_id' => $_REQUEST['pro_id']]);

        $email = Yii::$app->user->identity->email_id;
        $region = Yii::$app->user->identity->region;

         // notification for deleting the product
        $productid = $_REQUEST['pro_id'];                
        Yii::$app->runAction('notify/deleteuserproductnotify', ['email_id'=> $email, 'region'=>$region, 'productid' => $productid]);

        //return $productModel->delete();
        return Yii::$app->db->createCommand('UPDATE products SET p_status = "d" WHERE p_id = "'.$productid.'"')
        ->execute();
    }

    public function actionGetcategory(){
        $categories = Product::find()
                            ->select(['id' => 'p_category', 'text' => 'p_category'])
                            ->where(['LIKE', 'p_category', $_GET['q']])
                            ->groupBy('p_category')
                            ->asArray()
                            ->all();
        return json_encode($categories);
    }

    

    
}
