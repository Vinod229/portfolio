<?php

namespace app\assets;

use yii\web\AssetBundle;

/**
 * BOQ pages asset bundle.
 *
 * @author Vinod Tungana <vinod.tungana@antra.com>
 * @since 1.0
 */
class BoqAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    
    public $css = [
        'css/site.css',
        'css/bootstrap.min.css',
        'css/layout.css',
        'css/boq.css',
        'css/products.css',
        'css/si.css',
        'css/print.css',
        'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css',
        'https://canvasjs.com/assets/css/jquery-ui.1.11.2.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'
    ];
    
    public $js = [
        
        'js/accordian.js',
        'js/bootstrap.min.js',
        'js/layout.js',
        'js/boq.js',
        'js/load.js',
        'js/graph.js',
        'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js',
        'https://canvasjs.com/assets/script/jquery-ui.1.11.2.min.js',
        'https://canvasjs.com/assets/script/jquery.canvasjs.min.js',
        'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js'
        
    ];
    
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\web\jQueryAsset'
    ];
    
}
