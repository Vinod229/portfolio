<?php


namespace app\assets;

use yii\web\AssetBundle;

/**
 * Login/Registration pages asset bundle.
 *
 * @author Vinod Tungana <vinod.tungana@antra.com>
 * @since 1.0
 */
class ProfileAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/bootstrap.min.css',
        'css/select2.min.css',
        'css/theme.css',
        'css/profile.css',
        'css/media-queries.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css',
        'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.7.1/slick.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.7.1/slick-theme.min.css',
        'css/richtext.min.css',
    ];
    public $js = [
        'js/popper.min.js',
        'js/bootstrap.min.js',
        'js/jquery.exzoom.js',
        'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.7.1/slick.min.js',
        'js/jquery.richtext.min.js',
        'js/select2.min.js',
        'js/theme.js',
        'js/profile.js'
    ];
    public $depends = [
        'yii\web\YiiAsset',
        //'yii\bootstrap\BootstrapAsset',
        'yii\web\jQueryAsset'
    ];
}
