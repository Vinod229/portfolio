<?php


namespace app\assets;

use yii\web\AssetBundle;

/**
 * Login/Registration pages asset bundle.
 *
 * @author Vinod Tungana <vinod.tungana@antra.com>
 * @since 1.0
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/bootstrap.min.css',
        'css/select2.min.css',
        'css/theme.css',
        'css/media-queries.css',
        'css/access.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css'
    ];
    public $js = [
        'js/popper.min.js',
        'js/bootstrap.min.js',
        'js/select2.min.js',
        'js/access_theme.js'
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\web\jQueryAsset'
    ];
}
