<?php

namespace app\models;

use yii\base\Model;
use yii\db\ActiveRecord;
use yii\helpers\Html;
use Yii;

class ProjectForm extends Model
{

    public $p_id;
    public $p_title;
    public $p_summary;
    public $p_description;
    public $p_picture;
    public $p_video;
    public $p_rating;
    public $p_comment;
    public $created_on;
    public $is_public;

     /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['p_title', 'p_summary', 'p_description'], 'required'],
            [['p_picture'], 'file', 'skipOnEmpty' => true, 'extensions' => 'png, jpg, jpeg', 'maxSize' => 1024000,],
        ];
    }

    /**
     * @return array the scenarios.
     */
    public function scenarios() {
        $scenarios = parent::scenarios();
        $scenarios['addProject'] = ['p_title', 'p_summary', 'p_description', 'p_picture'];
        $scenarios['updateProject'] = ['p_id', 'p_title', 'p_summary', 'p_description', 'p_picture', 'is_public'];
	    return $scenarios;
    }

    public function attributeLabels()
    {
        return [
            'p_title' => 'Project Title',
            'p_summary' => 'Project Summary',
            'p_rating' => 'Project Rating',
            'p_picture' => 'Featured Picture',
            'p_video' => 'Featured Video',
            'p_description' => 'Project Description',
            'is_public' => 'Is Public'
        ];
    }

    public function addProject()
    {
        if ($this->validate()) {
            $project = new Project();
            
            $project->p_title = $this->p_title;
            $project->user_id = Yii::$app->user->identity->user_id;
            $project->p_summary = $this->p_summary;
            $project->p_description = $this->p_description;
            $project->is_public = false;
            if($this->p_picture){
                $project->p_picture =  $this->p_picture->baseName . '_' . strtotime('now') . '.' . $this->p_picture->extension;
            }
            
            return $project->save() ? $project->p_id : false;
        }
    }

    public function updateProject()
    {
        if ($this->validate()) {
            $proModel = new project();
            $project = $proModel->findOne(['p_id' => $this->p_id]);
            $project->p_title = $this->p_title;
            $project->p_summary = $this->p_summary;
            $project->p_description = $this->p_description;
            $project->is_public = $this->is_public;
            if($this->p_picture){
                $project->p_picture =  $this->p_picture->baseName . '_' . strtotime('now') . '.' . $this->p_picture->extension;
            }
            return $project->update() ? $project : null;
        }
        return false;
    }

    public function getCategories()
    {
        $product = new Product();
        $productCategories = $product->find()
                                    ->select('p_category')
                                    ->groupBy('p_category')
                                    ->asArray()
                                    ->all();
        
        return $productCategories;
    }

    public function getHogarProducts(){
        $products = (new \yii\db\Query())
                            ->select('*')
                            ->where(['p_hogar' => 1])
                            ->andWhere([ 'p_status' => 'a' ])
                            ->from('products')
                            ->all();
        return $products;
    }

    public function getNonhogarProducts(){
        $products = (new \yii\db\Query())
                            ->select('*')
                            ->where(['p_hogar' => 0])
                            ->andWhere([ 'p_status' => 'a' ])
                            ->from('products')
                            ->all();
        return $products;
    }

    public function getPagination($pageSize){
        $products = (new \yii\db\Query())
                            ->select('*')
                            ->from('products')
                            ->all();
        $productCount = count($products);
        if($productCount%$pageSize == 0){
            $pages = floor($productCount/$pageSize);
        } else {
            $pages = floor(($productCount/$pageSize)) + 1;
        }
        return $pages;
    }
    
    public function getProduct($pro_id){
        //$product = Product::findOne($pro_id);
        
        $product = (new \yii\db\Query())
                            ->select('*')
                            ->from('products')
                            ->where(['p_id' => $pro_id ])
                            ->one();
        
        return $product;
    }
}