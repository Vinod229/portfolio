<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\db\ActiveRecord;

/**
 * Customer is the model behind the Customer form.
 *
 *
 */
class Customer extends ActiveRecord
{
    
    public static function tableName()
    {
        return 'customers';
    }

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['customer_name', 'customer_email', 'customer_phone'], 'required'],
            ['customer_email', 'email']
        ];
    }



}