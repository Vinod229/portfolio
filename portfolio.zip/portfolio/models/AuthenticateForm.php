<?php

namespace app\models;

use Yii;
use yii\base\Model;
use app\models\User;

/**
 * LoginForm is the model behind the login form.
 *
 * @property User|null $user This property is read-only.
 *
 */
class AuthenticateForm extends Model
{
    public $user_id;
    public $u_code;
    public $name;
    public $email_id;
    public $phone;
    public $city;
    public $profession;
    public $experience;
    public $education;
    public $summary;
    public $conumber;
    public $password;
    public $repeat_password;
    public $old_password;
    public $u_picture;
    public $authKey;
    public $verify_code;
    public $rememberMe = true;

    private $_user = false;


    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['email_id', 'name', 'phone', 'city', 'profession', 'experience', 'summary', 'conumber', 'password', 'repeat_password', 'old_password', 'verify_code', 'education'], 'required'],
            [['u_picture'], 'file', 'skipOnEmpty' => true, 'extensions' => 'png, jpg', 'maxSize' => 1024000,],
            ['email_id', 'email'],
            ['repeat_password', 'compare', 'compareAttribute' => 'password', 'on' => ['register', 'resetpwd', 'changePassword']],
            ['password', 'validatePassword', 'on' => 'login'], // password is validated by validatePassword()
            ['verify_code', 'captcha', 'captchaAction'=>'/access/captcha', 'on' => ['register']],
            ['old_password', 'validateOldPwd', 'on' => 'changePassword'],
            ['password', 'passwordrule', 'on' => ['register', 'resetpwd', 'changePassword']],
            ['email_id', 'existance', 'on' => 'forgetpwd'],
        ];
    }

    /**
     * @return array the scenarios.
     */
    public function scenarios() {
        $scenarios = parent::scenarios();
        $scenarios['register'] = ['name', 'phone',  'email_id', 'city', 'profession', 'password', 'repeat_password'];
        $scenarios['login'] = ['email_id', 'password'];
        $scenarios['forgetpwd'] = ['email_id'];
        $scenarios['resetpwd'] = ['authKey', 'password', 'repeat_password'];
        $scenarios['updateProfile'] = ['name', 'profession', 'phone', 'city', 'conumber', 'education', 'summary', 'experience', 'u_picture'];
        $scenarios['changePassword'] = ['password', 'repeat_password', 'old_password'];
	    return $scenarios;
    }


    public function passwordrule($attribute){
        $password = $this->$attribute;
        if(strlen($password) < 8){
            $this->addError($attribute, 'Password must contain more than 8 characters.');
        } else if(!preg_match('~[0-9]~', $password)){
            $this->addError($attribute, 'Password must contain atleast one number.');
        } else if (!preg_match('/[A-Z]/', $password)){
            $this->addError($attribute, 'Password must contain atleast one Upper case letter.');
        } else if (!preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $password)) {
            $this->addError($attribute, 'Password must contain atleast one Special Character.');
        }
    }


    public function existance($attribute)
    {
        $user = $this->getUser();
        if(!$user){
            $this->addError($attribute, 'Email does not exist.');
        }
    }


    public function validateOldPwd($attribute, $params)
    {  
        $user = User::findOne(['email_id' => Yii::$app->user->identity->email_id]);
        if($user->password != md5($this->$attribute)){
            $this->addError($attribute, 'Old Password is not correct.');
        }
    }


    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validatePassword($attribute, $params)
    {
        if (!$this->hasErrors()) {
            $user = $this->getUser();
            
            if (!$user || !$user->validatePassword($this->password, $this->email_id)) {
                $this->addError($attribute, 'Incorrect username or password.');
            }
        }
    }


    /**
     * Logs in a user using the provided username and password.
     * @return bool whether the user is logged in successfully
     */
    public function login()
    {
        if ($this->validate()) {
            return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600*24*30 : 0);
        }
        return false;
    }


    /**
     * 
     */
    public function forgetpwd()
    {
        if ($this->validate()) {
            $user = new User();
            $useridentity = $user->findOne(['email_id' => $this->email_id]);
            $useridentity->authKey =  md5(rand(0, 9).rand(0, 9).rand(0, 9).rand(0, 9));
            return $useridentity->update() ? $useridentity->authKey : false;
        }
        return false;
    }


    /**
     * 
     */
    public function resetpwd()
    {
        if ($this->validate()) {
            $user = new User();
            $useridentity = $user->findOne(['authKey' => $this->authKey]);
            $useridentity->password =  md5($this->password);
            $useridentity->authKey =  '';

            return $useridentity->update() ? true : false;
        }
        return false;
    }


    /**
     * Register the user details into {users} table
     */
    public function register()
    {
        if ($this->validate()) {
            $user = new User();
            $user->u_code = 'PRO'.date('ym').rand(0, 9).rand(0, 9).rand(0, 9);
            $user->name =  $this->name;
            $user->email_id =  $this->email_id;
            $user->phone =  $this->phone;
            $user->city =  $this->city;
            $user->profession =  $this->profession;;
            $user->password =  md5($this->password);
            $user->active = 0;
            
            return $user->save() ? $user : null;
        }
    }


    /**
     * Update User information
     */
    public function update()
    {
        /*
        echo '<pre>';
        print_r($this);
        echo '</pre>';
        */
        if ($this->validate()) {
            $userModel = new User();

            $user = $userModel->findOne(['email_id' => Yii::$app->user->identity->email_id]);
            
            $user->name =  $this->name;
            $user->city =  $this->city;
            $user->phone =  $this->phone;
            $user->profession =  $this->profession;
            $user->education =  $this->education;
            $user->experience =  $this->experience;
            $user->conumber =  $this->conumber;
            $user->summary =  $this->summary;
            if($this->u_picture){
                $user->u_picture =  $this->u_picture->baseName . '_' . strtotime('now') . '.' . $this->u_picture->extension;
            }

            return $user->update() ? $user : null;
        }
        return false;
    }


    /**
     * Update User information
     */
    public function changePwd()
    {
        if ($this->validate()) {
            $userModel = new User();
            $user = $userModel->findOne(['email_id' => Yii::$app->user->identity->email_id]);
            
            $user->password =  md5($this->password);
            
            return $user->update() ? $user : null;
        }
        return false;
    }

    
    /**
     * Finds user by [[username]]
     *
     * @return User|null
     */
    public function getUser()
    {
        if ($this->_user === false) {
            $this->_user = User::findByUsername($this->email_id);
        }
        return $this->_user;
    }
}