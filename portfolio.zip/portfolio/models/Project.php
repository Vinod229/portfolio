<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\db\ActiveRecord;

/**
 * Customer is the model behind the Customer form.
 *
 *
 */
class Project extends ActiveRecord
{
    
    public static function tableName()
    {
        return 'projects';
    }

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['p_title', 'p_summary', 'p_description'], 'required'],
        ];
    }

    public function getProjects($user_id){
        $projects = (new \yii\db\Query())
                            ->select('*')
                            ->from('projects')
                            ->where(['user_id' => $user_id])
                            ->all();
        return $projects;
    }



}