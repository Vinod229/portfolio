<?php

namespace app\models;

use yii\base\Model;
use yii\db\ActiveRecord;
use Yii;

class Service extends ActiveRecord
{


    public static function tableName()
    {
        return 'services';
    }

     /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['s_name'], 'required'],
        ];
    }

    public function getServices($user_id){
        $services = (new \yii\db\Query())
                            ->select('*')
                            ->from('services')
                            ->where(['user_id' => $user_id])
                            ->all();
        return $services;
    }

}